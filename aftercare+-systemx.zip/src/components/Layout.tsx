import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Activity, LayoutDashboard, LogOut, User } from 'lucide-react';
import { motion } from 'motion/react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const isHospital = location.pathname.includes('/hospital');
  const isPatient = location.pathname.includes('/patient');

  if (location.pathname === '/') return <>{children}</>;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-2">
              <Activity className="h-8 w-8 text-emerald-600" />
              <span className="font-bold text-xl tracking-tight text-slate-900">
                AfterCare<span className="text-emerald-600">+</span> SystemX
              </span>
            </div>
            <div className="flex items-center gap-4">
              {isHospital && (
                <span className="text-sm font-medium text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                  Hospital Portal
                </span>
              )}
              {isPatient && (
                <span className="text-sm font-medium text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                  Patient Portal
                </span>
              )}
              <Link
                to="/"
                className="p-2 text-slate-400 hover:text-slate-600 transition-colors"
                title="Logout"
              >
                <LogOut className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </nav>
      <motion.main
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"
      >
        {children}
      </motion.main>
    </div>
  );
}
