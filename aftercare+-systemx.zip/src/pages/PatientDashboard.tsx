import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Heart, Thermometer, Activity, Pill, AlertTriangle, CheckCircle, Camera, Volume2 } from 'lucide-react';
import { motion } from 'motion/react';
import { Patient, Medication, HealthLog } from '../types';

export default function PatientDashboard() {
  const { id } = useParams();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [meds, setMeds] = useState<Medication[]>([]);
  const [loading, setLoading] = useState(true);
  const [sosActive, setSosActive] = useState(false);

  // Form State
  const [heartRate, setHeartRate] = useState('');
  const [systolic, setSystolic] = useState('');
  const [diastolic, setDiastolic] = useState('');
  const [temp, setTemp] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [submitted, setSubmitted] = useState(false);

  // Wound State
  const [woundImage, setWoundImage] = useState<string | null>(null);
  const [analyzingWound, setAnalyzingWound] = useState(false);
  const [woundResult, setWoundResult] = useState<any>(null);

  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = async () => {
    try {
      const res = await fetch(`/api/patients/${id}`);
      const data = await res.json();
      setPatient(data.patient);
      setMeds(data.meds);
      setLoading(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(false);
    
    try {
      const res = await fetch('/api/logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patient_id: id,
          heart_rate: parseInt(heartRate),
          systolic_bp: parseInt(systolic),
          diastolic_bp: parseInt(diastolic),
          temperature: parseFloat(temp),
          symptoms
        })
      });
      
      if (res.ok) {
        setSubmitted(true);
        setHeartRate('');
        setSystolic('');
        setDiastolic('');
        setTemp('');
        setSymptoms('');
        setTimeout(() => setSubmitted(false), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSOS = async () => {
    setSosActive(true);
    try {
      await fetch('/api/emergency', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patient_id: id })
      });
      alert('Emergency Alert Sent to Hospital!');
    } catch (err) {
      console.error(err);
    } finally {
      setSosActive(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setWoundImage(reader.result as string);
        setWoundResult(null); // Reset previous result
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeWound = async () => {
    if (!woundImage) return;
    setAnalyzingWound(true);
    try {
      const res = await fetch('/api/analyze-wound', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patient_id: id, image_data: woundImage })
      });
      const data = await res.json();
      setWoundResult(data.analysis);
    } catch (err) {
      console.error(err);
      alert('Analysis failed');
    } finally {
      setAnalyzingWound(false);
    }
  };

  const playVoiceReminder = (medName: string) => {
    const utterance = new SpeechSynthesisUtterance(`It is time to take your medication: ${medName}`);
    window.speechSynthesis.speak(utterance);
  };

  if (loading) return <div className="p-8 text-center text-xl">Loading...</div>;

  return (
    <div className="space-y-8 max-w-2xl mx-auto pb-20">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Hello, {patient?.name}</h1>
          <p className="text-slate-500">Package: <span className="font-semibold text-blue-600">{patient?.care_package}</span></p>
        </div>
        <div className={`px-4 py-2 rounded-full text-sm font-bold ${
          patient?.risk_level === 'High' ? 'bg-red-100 text-red-700' :
          patient?.risk_level === 'Medium' ? 'bg-amber-100 text-amber-700' :
          'bg-emerald-100 text-emerald-700'
        }`}>
          Status: {patient?.risk_level} Risk
        </div>
      </div>

      {/* SOS Button */}
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={handleSOS}
        className={`w-full py-8 rounded-3xl text-3xl font-bold shadow-xl flex items-center justify-center gap-4 transition-colors ${
          sosActive ? 'bg-red-700 text-white' : 'bg-red-500 text-white hover:bg-red-600'
        }`}
      >
        <AlertTriangle className="h-12 w-12" />
        EMERGENCY SOS
      </motion.button>

      {/* Wound Analysis Section */}
      <div className="bg-white p-8 rounded-3xl shadow-lg border border-slate-100">
        <div className="flex items-center gap-3 mb-6">
          <Camera className="h-8 w-8 text-purple-500" />
          <h2 className="text-2xl font-bold text-slate-800">Wound Check AI</h2>
        </div>
        
        <div className="space-y-4">
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-8 text-center bg-slate-50 hover:bg-slate-100 transition-colors relative overflow-hidden">
            {woundImage ? (
              <img src={woundImage} alt="Wound Preview" className="mx-auto h-64 object-contain rounded-lg" />
            ) : (
              <div className="text-slate-400">
                <Camera className="h-12 w-12 mx-auto mb-2" />
                <p>Tap to take a photo of your wound</p>
              </div>
            )}
            <input 
              type="file" 
              accept="image/*" 
              capture="environment"
              onChange={handleImageUpload}
              className="absolute inset-0 opacity-0 cursor-pointer" 
            />
          </div>

          {woundImage && !woundResult && (
            <button
              onClick={analyzeWound}
              disabled={analyzingWound}
              className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-purple-200 transition-all disabled:opacity-50"
            >
              {analyzingWound ? 'Analyzing...' : 'Analyze Wound Risk'}
            </button>
          )}

          {woundResult && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-6 rounded-xl border ${
                woundResult.risk_level === 'High' ? 'bg-red-50 border-red-200' : 
                woundResult.risk_level === 'Medium' ? 'bg-amber-50 border-amber-200' : 
                'bg-emerald-50 border-emerald-200'
              }`}
            >
              <h3 className="font-bold text-lg mb-2">Analysis Result: {woundResult.risk_level} Risk</h3>
              <p className="text-slate-700 mb-4">{woundResult.analysis}</p>
              <div className="bg-white/50 p-4 rounded-lg">
                <span className="font-bold text-sm uppercase tracking-wide opacity-70">Advice</span>
                <p className="text-slate-900 font-medium">{woundResult.advice}</p>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* Vitals Form */}
      <div className="bg-white p-8 rounded-3xl shadow-lg border border-slate-100">
        <div className="flex items-center gap-3 mb-6">
          <Activity className="h-8 w-8 text-blue-500" />
          <h2 className="text-2xl font-bold text-slate-800">Daily Health Check</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-500 uppercase tracking-wider">Heart Rate</label>
              <div className="relative">
                <Heart className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
                <input
                  type="number"
                  required
                  value={heartRate}
                  onChange={e => setHeartRate(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 rounded-xl border-2 border-transparent focus:border-blue-500 focus:bg-white transition-all text-xl font-mono"
                  placeholder="BPM"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-500 uppercase tracking-wider">Temp (°C)</label>
              <div className="relative">
                <Thermometer className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
                <input
                  type="number"
                  step="0.1"
                  required
                  value={temp}
                  onChange={e => setTemp(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 rounded-xl border-2 border-transparent focus:border-blue-500 focus:bg-white transition-all text-xl font-mono"
                  placeholder="36.5"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-500 uppercase tracking-wider">Blood Pressure (Sys/Dia)</label>
            <div className="grid grid-cols-2 gap-4">
              <input
                type="number"
                required
                value={systolic}
                onChange={e => setSystolic(e.target.value)}
                className="w-full px-4 py-4 bg-slate-50 rounded-xl border-2 border-transparent focus:border-blue-500 focus:bg-white transition-all text-xl font-mono text-center"
                placeholder="120"
              />
              <input
                type="number"
                required
                value={diastolic}
                onChange={e => setDiastolic(e.target.value)}
                className="w-full px-4 py-4 bg-slate-50 rounded-xl border-2 border-transparent focus:border-blue-500 focus:bg-white transition-all text-xl font-mono text-center"
                placeholder="80"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-500 uppercase tracking-wider">Symptoms / Notes</label>
            <textarea
              value={symptoms}
              onChange={e => setSymptoms(e.target.value)}
              className="w-full px-4 py-4 bg-slate-50 rounded-xl border-2 border-transparent focus:border-blue-500 focus:bg-white transition-all text-lg"
              placeholder="Feeling dizzy, headache..."
              rows={3}
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-200 transition-all"
          >
            Submit Health Log
          </button>

          {submitted && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-emerald-50 text-emerald-700 rounded-xl flex items-center gap-3"
            >
              <CheckCircle className="h-6 w-6" />
              <span>Data logged successfully! AI is analyzing...</span>
            </motion.div>
          )}
        </form>
      </div>

      {/* Medications */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="flex items-center gap-3 mb-6">
          <Pill className="h-8 w-8 text-emerald-500" />
          <h2 className="text-2xl font-bold text-slate-800">Medication Reminders</h2>
        </div>
        <div className="space-y-4">
          {meds.map(med => (
            <div key={med.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
              <div>
                <h3 className="font-bold text-lg text-slate-900">{med.name}</h3>
                <p className="text-slate-500">{med.dosage} • {med.schedule}</p>
              </div>
              <button 
                onClick={() => playVoiceReminder(med.name)}
                className="p-3 bg-emerald-100 text-emerald-700 rounded-full hover:bg-emerald-200 transition-colors"
              >
                <Volume2 className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
