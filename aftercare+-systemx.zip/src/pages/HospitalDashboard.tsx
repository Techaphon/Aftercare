import React, { useState, useEffect, useRef } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area 
} from 'recharts';
import { AlertTriangle, CheckCircle, Clock, User, Activity, Search, Camera } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Patient, Alert, HealthLog, WoundLog } from '../types';
import { format } from 'date-fns';

export default function HospitalDashboard() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [logs, setLogs] = useState<HealthLog[]>([]);
  const [woundLogs, setWoundLogs] = useState<WoundLog[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const ws = useRef<WebSocket | null>(null);

  useEffect(() => {
    fetchPatients();
    connectWebSocket();
    return () => ws.current?.close();
  }, []);

  useEffect(() => {
    if (selectedPatient) {
      fetchPatientDetails(selectedPatient.id);
    }
  }, [selectedPatient]);

  const connectWebSocket = () => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = new WebSocket(`${protocol}//${window.location.host}/api/ws`);
    ws.current = socket;
    
    socket.onopen = () => console.log('WS Connected');
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'NEW_ALERT' || data.type === 'EMERGENCY') {
        fetchPatients(); // Refresh risk levels
        // Add to local alerts immediately for UI feedback
        const newAlert: Alert = {
          id: Date.now(), // temp id
          patient_id: data.patient_id,
          type: data.type === 'EMERGENCY' ? 'Emergency' : 'AbnormalVitals',
          message: data.message,
          status: 'Active',
          timestamp: new Date().toISOString()
        };
        setAlerts(prev => [newAlert, ...prev]);
      } else if (data.type === 'UPDATE_PATIENT') {
        fetchPatients();
        if (selectedPatient?.id === data.patient_id) {
          fetchPatientDetails(data.patient_id);
        }
      }
    };

    socket.onclose = () => {
      console.log('WS Disconnected. Reconnecting...');
      setTimeout(connectWebSocket, 3000);
    };
  };

  const fetchPatients = async () => {
    const res = await fetch('/api/patients');
    const data = await res.json();
    setPatients(data);
    setLoading(false);
  };

  const fetchPatientDetails = async (id: number) => {
    const res = await fetch(`/api/patients/${id}`);
    const data = await res.json();
    setLogs(data.logs.reverse()); // Reverse for chart order
    setWoundLogs(data.woundLogs || []);
    setAlerts(data.alerts);
  };

  const resolveAlert = async (id: number) => {
    await fetch(`/api/alerts/${id}/resolve`, { method: 'POST' });
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'Resolved' } : a));
  };

  if (loading) return <div className="p-8">Loading Dashboard...</div>;

  return (
    <div className="grid grid-cols-12 gap-6 h-[calc(100vh-8rem)]">
      {/* Sidebar: Patient List */}
      <div className="col-span-3 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
        <div className="p-4 border-b border-slate-100 bg-slate-50">
          <h2 className="font-bold text-slate-700 mb-2">Patients</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search patients..." 
              className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="overflow-y-auto flex-1 p-2 space-y-2">
          {patients.map(p => (
            <button
              key={p.id}
              onClick={() => setSelectedPatient(p)}
              className={`w-full text-left p-3 rounded-xl transition-all ${
                selectedPatient?.id === p.id ? 'bg-blue-50 border-blue-200 ring-1 ring-blue-200' : 'hover:bg-slate-50 border border-transparent'
              }`}
            >
              <div className="flex justify-between items-start mb-1">
                <span className="font-semibold text-slate-900">{p.name}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  p.risk_level === 'High' ? 'bg-red-100 text-red-700' :
                  p.risk_level === 'Medium' ? 'bg-amber-100 text-amber-700' :
                  'bg-emerald-100 text-emerald-700'
                }`}>
                  {p.risk_level}
                </span>
              </div>
              <div className="text-xs text-slate-500 truncate">{p.condition}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="col-span-9 space-y-6 overflow-y-auto pr-2 pb-20">
        {selectedPatient ? (
          <>
            {/* Patient Header */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex justify-between items-start">
              <div>
                <h1 className="text-2xl font-bold text-slate-900 mb-1">{selectedPatient.name}</h1>
                <div className="flex gap-4 text-sm text-slate-500">
                  <span className="flex items-center gap-1"><User className="h-4 w-4" /> {selectedPatient.age} yrs</span>
                  <span className="flex items-center gap-1"><Activity className="h-4 w-4" /> {selectedPatient.condition}</span>
                  <span className="flex items-center gap-1 px-2 py-0.5 bg-slate-100 rounded-md text-slate-600 font-medium">
                    Package: {selectedPatient.care_package}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-slate-400 mb-1">Current Risk Assessment</div>
                <div className={`text-2xl font-bold ${
                  selectedPatient.risk_level === 'High' ? 'text-red-600' :
                  selectedPatient.risk_level === 'Medium' ? 'text-amber-600' :
                  'text-emerald-600'
                }`}>
                  {selectedPatient.risk_level} Risk
                </div>
              </div>
            </div>

            {/* Alerts Section */}
            <div className="space-y-4">
              <h3 className="font-bold text-slate-700 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                Active Alerts
              </h3>
              <AnimatePresence>
                {alerts.filter(a => a.status === 'Active').length === 0 ? (
                  <div className="p-4 bg-slate-50 rounded-xl text-slate-400 text-sm italic">
                    No active alerts for this patient.
                  </div>
                ) : (
                  alerts.filter(a => a.status === 'Active').map(alert => (
                    <motion.div
                      key={alert.id}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className={`p-4 rounded-xl border flex justify-between items-center ${
                        alert.type === 'Emergency' ? 'bg-red-50 border-red-200 text-red-800' : 'bg-amber-50 border-amber-200 text-amber-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <AlertTriangle className="h-5 w-5" />
                        <div>
                          <div className="font-bold">{alert.type}</div>
                          <div className="text-sm opacity-90">{alert.message}</div>
                          <div className="text-xs opacity-70 mt-1">{format(new Date(alert.timestamp), 'PP p')}</div>
                        </div>
                      </div>
                      <button
                        onClick={() => resolveAlert(alert.id)}
                        className="px-4 py-2 bg-white/50 hover:bg-white/80 rounded-lg text-sm font-semibold transition-colors"
                      >
                        Resolve
                      </button>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>

            {/* Wound Gallery */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h3 className="font-bold text-slate-700 mb-4 flex items-center gap-2">
                <Camera className="h-5 w-5 text-purple-500" />
                Wound Analysis History
              </h3>
              {woundLogs.length === 0 ? (
                <div className="text-slate-400 text-sm italic">No wound logs available.</div>
              ) : (
                <div className="grid grid-cols-3 gap-4">
                  {woundLogs.map(log => {
                    const analysis = JSON.parse(log.analysis_result);
                    return (
                      <div key={log.id} className="border rounded-xl p-3 space-y-2">
                        <img src={log.image_data} alt="Wound" className="w-full h-32 object-cover rounded-lg" />
                        <div>
                          <div className={`text-xs font-bold uppercase ${
                            log.risk_level === 'High' ? 'text-red-600' : 
                            log.risk_level === 'Medium' ? 'text-amber-600' : 
                            'text-emerald-600'
                          }`}>
                            {log.risk_level} Risk
                          </div>
                          <div className="text-xs text-slate-500 mt-1 line-clamp-2">
                            {analysis.analysis}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-1">
                            {format(new Date(log.timestamp), 'PP p')}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Charts */}
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-700 mb-4">Heart Rate Trend</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={logs}>
                      <defs>
                        <linearGradient id="colorHr" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="timestamp" tickFormatter={(t) => format(new Date(t), 'HH:mm')} stroke="#94a3b8" fontSize={12} />
                      <YAxis stroke="#94a3b8" fontSize={12} domain={['auto', 'auto']} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        labelFormatter={(t) => format(new Date(t), 'PP p')}
                      />
                      <Area type="monotone" dataKey="heart_rate" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorHr)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-700 mb-4">Blood Pressure</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={logs}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="timestamp" tickFormatter={(t) => format(new Date(t), 'HH:mm')} stroke="#94a3b8" fontSize={12} />
                      <YAxis stroke="#94a3b8" fontSize={12} domain={['auto', 'auto']} />
                      <Tooltip 
                         contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                         labelFormatter={(t) => format(new Date(t), 'PP p')}
                      />
                      <Line type="monotone" dataKey="systolic_bp" stroke="#ef4444" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="diastolic_bp" stroke="#f59e0b" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="h-full flex items-center justify-center text-slate-400">
            Select a patient to view details
          </div>
        )}
      </div>
    </div>
  );
}
