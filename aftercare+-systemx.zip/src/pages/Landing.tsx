import React from 'react';
import { Link } from 'react-router-dom';
import { Activity, Stethoscope, User } from 'lucide-react';
import { motion } from 'motion/react';

export default function Landing() {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-8">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex flex-col justify-center space-y-6 text-white"
        >
          <div className="flex items-center gap-3">
            <Activity className="h-12 w-12 text-emerald-400" />
            <h1 className="text-4xl font-bold tracking-tight">
              AfterCare<span className="text-emerald-400">+</span> SystemX
            </h1>
          </div>
          <p className="text-xl text-slate-300 leading-relaxed">
            Intelligent post-discharge monitoring powered by AI. 
            Bridging the gap between hospital and home recovery.
          </p>
          <div className="flex gap-4 pt-4">
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Wound AI Analysis
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
              Care Packages
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl p-8 shadow-2xl space-y-8"
        >
          <h2 className="text-2xl font-semibold text-slate-900 text-center">Select Your Portal</h2>
          
          <div className="grid gap-4">
            <Link 
              to="/patient/1" 
              className="group relative flex items-center gap-4 p-6 rounded-2xl border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-300"
            >
              <div className="p-4 rounded-xl bg-emerald-100 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <User className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Patient Access</h3>
                <p className="text-sm text-slate-500">Log vitals, view meds, SOS</p>
              </div>
            </Link>

            <Link 
              to="/hospital" 
              className="group relative flex items-center gap-4 p-6 rounded-2xl border-2 border-slate-100 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300"
            >
              <div className="p-4 rounded-xl bg-blue-100 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Stethoscope className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Hospital Dashboard</h3>
                <p className="text-sm text-slate-500">Monitor patients, AI insights</p>
              </div>
            </Link>
          </div>
          
          <p className="text-center text-xs text-slate-400">
            Secure Medical Data Protocol Enabled
          </p>
        </motion.div>
      </div>
    </div>
  );
}
