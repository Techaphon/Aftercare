export interface Patient {
  id: number;
  name: string;
  age: number;
  condition: string;
  risk_level: 'Low' | 'Medium' | 'High';
  care_package: string;
  admission_date: string;
  discharge_date: string;
  notes?: string;
}

export interface HealthLog {
  id: number;
  patient_id: number;
  heart_rate: number;
  systolic_bp: number;
  diastolic_bp: number;
  temperature: number;
  symptoms: string;
  timestamp: string;
}

export interface WoundLog {
  id: number;
  patient_id: number;
  image_data: string;
  analysis_result: string; // JSON string
  risk_level: 'Low' | 'Medium' | 'High';
  timestamp: string;
}

export interface Alert {
  id: number;
  patient_id: number;
  type: 'Emergency' | 'MissedMedication' | 'AbnormalVitals';
  message: string;
  status: 'Active' | 'Resolved';
  timestamp: string;
}

export interface Medication {
  id: number;
  patient_id: number;
  name: string;
  dosage: string;
  schedule: string;
}
